from enum import Enum

class PerceivedDeviceType(Enum):
    Undefined           = 0
    DigitalStillCamera  = 1
