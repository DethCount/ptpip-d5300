from enum import Enum

class InternalFlashMode(Enum):
    TTLMode = 0x00
    ManualFlashMode = 0x01
