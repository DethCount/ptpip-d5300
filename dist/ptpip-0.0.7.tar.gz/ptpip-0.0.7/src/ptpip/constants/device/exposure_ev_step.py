from enum import Enum

class ExposureEVStep(Enum):
    ThirdEV = 0x00 # 0
    HalfEV  = 0x01 # 1
