from enum import Enum

class InternalFlashStatus(Enum):
    Charging    = 0x00
    Ready       = 0x01
