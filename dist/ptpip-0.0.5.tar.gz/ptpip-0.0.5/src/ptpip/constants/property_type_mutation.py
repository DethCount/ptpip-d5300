from enum import Enum

class PropertyTypeMutation(Enum):
    Undefined   = 0x0
    Range       = 0x1
    Enumeration = 0x2
