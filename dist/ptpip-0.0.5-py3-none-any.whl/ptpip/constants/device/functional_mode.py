from enum import Enum

class FunctionalMode(Enum):
    Normal      = 0x00
    Sleeping    = 0x01
