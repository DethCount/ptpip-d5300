from ptpip.data_object.uint32_array import Uint32Array

class ObjectHandleArray(Uint32Array):
	pass
