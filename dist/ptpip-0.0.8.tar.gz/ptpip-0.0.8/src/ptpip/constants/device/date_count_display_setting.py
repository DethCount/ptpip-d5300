from enum import Enum

class DateCountDisplaySetting(Enum):
    Days            = 0x00
    YearDate        = 0x01
    YearMonthDate   = 0x02
