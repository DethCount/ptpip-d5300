from enum import Enum

class ReadMode(Enum):
    ReadOnly    = 0x00
    ReadWrite   = 0x01
