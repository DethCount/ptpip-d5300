from enum import Enum

class ExternalSpeedLightStatus(Enum):
    NotCharged  = 0x00
    Ready       = 0x01
