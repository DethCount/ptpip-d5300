from enum import Enum

class OnOffProperty(Enum):
    Off = 0x00
    On  = 0x01
