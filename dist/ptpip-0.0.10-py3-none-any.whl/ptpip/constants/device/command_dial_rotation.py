from enum import Enum

class CommandDialRotation(Enum):
    NotPerformed = 0x00
    Performed = 0x01
