from enum import Enum

class WBBracketingStep(Enum):
    OneEV   = 0x00
    TwoEV   = 0x01
    ThreeEV = 0x02
