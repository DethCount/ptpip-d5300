from ptpip.data_object.uint16_array import Uint16Array

class ObjectPropCodeArray(Uint16Array):
	pass
